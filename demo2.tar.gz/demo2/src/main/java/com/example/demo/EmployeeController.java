package com.example.demo;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@RestController
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @RequestMapping(value = "/getEmployees", produces = MediaType.APPLICATION_JSON_VALUE)
    public BaseResponse getEmployees() throws JsonProcessingException {
        List<Employee> employees = employeeService.getEmployees();
        BaseResponse baseResponse = new BaseResponse();
        baseResponse.setStatus("OK");
        baseResponse.setEmployees(employees);
        return baseResponse;
    }

    @RequestMapping(value = "/find/{empId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public BaseResponse findEmployee(@PathVariable("empId") String empId) throws JsonProcessingException {
        Employee employee = employeeService.getEmployee(empId);
        BaseResponse baseResponse = new BaseResponse();
        baseResponse.setStatus("OK");
        baseResponse.setEmployees(Arrays.asList(employee));
        return baseResponse;
    }
}
