package com.example.demo;

import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class EmployeeDao {

    public List<Employee> getEmployees() {
        List<Employee> employees = new ArrayList<>();
        Employee e1 = new Employee();
        e1.setFirstName("Firstname1");
        e1.setLastName("Lastname1");
        e1.setDesignation("Executive");
        e1.setExp(15);
        employees.add(e1);

        Employee e2 = new Employee();
        e2.setFirstName("Firstname2");
        e2.setLastName("Lastname2");
        e2.setDesignation("Manager");
        e2.setExp(10);
        employees.add(e2);

        Employee e3 = new Employee();
        e3.setFirstName("Firstname3");
        e3.setLastName("Lastname3");
        e3.setDesignation("Developer");
        e3.setExp(5);
        employees.add(e3);

        return employees;
    }

    public Employee getEmployee(String empId) {
        if (empId.equals("2")) {
            Employee e1 = new Employee();
            e1.setFirstName("Firstname1");
            e1.setLastName("Lastname1");
            e1.setDesignation("Executive");
            e1.setExp(15);
            return e1;
        } else {
            return null;
        }
    }
}
