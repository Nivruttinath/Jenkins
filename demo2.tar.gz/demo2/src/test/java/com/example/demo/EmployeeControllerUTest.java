package com.example.demo;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(webEnvironment=SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
public class EmployeeControllerUTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    private EmployeeService employeeService;

    @Test
    public void test_get_employees() throws Exception {
        List<Employee> employees = new ArrayList<>();
        Employee e1 = new Employee();
        e1.setFirstName("Firstname1");
        e1.setLastName("Lastname1");
        e1.setDesignation("Executive");
        e1.setExp(15);
        employees.add(e1);

        Employee e2 = new Employee();
        e2.setFirstName("Firstname2");
        e2.setLastName("Lastname2");
        e2.setDesignation("Manager");
        e2.setExp(10);
        employees.add(e2);

        when(employeeService.getEmployees()).thenReturn(employees);

        mvc.perform(get("/getEmployees"))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").exists())
                .andExpect(jsonPath("$.employees").exists());
    }

    @Test
    public void test_find_employee_by_id() throws Exception {
        List<Employee> employees = new ArrayList<>();
        Employee e1 = new Employee();
        e1.setFirstName("Firstname1");
        e1.setLastName("Lastname1");
        e1.setDesignation("Executive");
        e1.setExp(15);
        employees.add(e1);

        when(employeeService.getEmployee(anyString())).thenReturn(e1);

        mvc.perform(get("/find/2"))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").exists())
                .andExpect(jsonPath("$.employees").exists())
                .andExpect(jsonPath("$.employees[0].firstName").value("Firstname1"))
                .andExpect(jsonPath("$.employees[0].lastName").value("Lastname1"));
    }
}
