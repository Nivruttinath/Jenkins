package com.example.demo;

import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

public class EmployeeDaoUTest {
    @Test
    public void test_get_employees() {
        List<Employee> employeeList = new EmployeeDao().getEmployees();

        assertNotNull(employeeList);
        assertTrue(employeeList.size() == 3);
        assertEquals("Firstname1", employeeList.get(0).getFirstName());
    }

    @Test
    public void test_find_emp_by_id() {
        Employee employee = new EmployeeDao().getEmployee("2");
        assertNotNull(employee);
        assertEquals("Firstname1", employee.getFirstName());
    }
}
